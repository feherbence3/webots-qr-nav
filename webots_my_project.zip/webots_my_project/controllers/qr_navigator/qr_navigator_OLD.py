from controller import Robot

robot = Robot()
timestep = int(robot.getBasicTimeStep())

# Motors
left_motor = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))

# Camera - Let's see if this causes the crash
cam = robot.getDevice('camera')
cam.enable(timestep)

print("Robot is alive and watching!")

while robot.step(timestep) != -1:
    left_motor.setVelocity(2.0)
    right_motor.setVelocity(2.0)