from controller import Robot

robot = Robot()
timestep = int(robot.getBasicTimeStep())  # usually 32 or 64

# ─── Get motors ─────────────────────────────────────────────────────────────
left_motor  = robot.getDevice('left wheel motor')
right_motor = robot.getDevice('right wheel motor')

left_motor.setPosition(float('inf'))   # velocity mode
right_motor.setPosition(float('inf'))
left_motor.setVelocity(0.0)
right_motor.setVelocity(0.0)

# ─── TUNABLE PARAMETERS ─────────────────────────────────────────────────────
# Phase 1: Turn left 90° in place
TURN_SPEED     = 4.0          # rad/s — 3.0 to 6.0 is good range
TURN_DURATION  = 1.184         # seconds — tune this for exactly 90°
                              # start ~1.3–1.45, adjust ±0.01 s steps

# Phase 2: Forward speed after turn
FORWARD_SPEED  = 3.5          # rad/s — comfortable cruise speed

# ──────────────────────────────────────────────────────────────────────────────

print("e-puck: Turn left 90° then go forward forever")
print(f"Turn: {TURN_SPEED:.2f} rad/s during {TURN_DURATION:.3f} s")
print(f"Forward: {FORWARD_SPEED:.2f} rad/s")

start_time = robot.getTime()
phase = "TURNING"             # "TURNING" → "FORWARD"

while robot.step(timestep) != -1:

    elapsed = robot.getTime() - start_time

    if phase == "TURNING":

        if elapsed >= TURN_DURATION:
            # Switch to forward phase
            phase = "FORWARD"
            print(f"→ Turn finished after {elapsed:.3f} s — now going forward")
        else:
            # Turn left (counter-clockwise): left backward, right forward
            left_motor.setVelocity(-TURN_SPEED)
            right_motor.setVelocity(+TURN_SPEED)

    elif phase == "FORWARD":
        # Go straight forever
        left_motor.setVelocity(FORWARD_SPEED)
        right_motor.setVelocity(FORWARD_SPEED)

    # Optional: show progress during turn
    if phase == "TURNING" and int(elapsed * 2) != int((elapsed - timestep/1000.0) * 2):
        print(f"  turning... {elapsed:.2f} / {TURN_DURATION:.2f} s")

print("Controller stopped (simulation ended).")